import os
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables from .env file
env_path = Path('.') / '.env'
load_dotenv(dotenv_path=env_path)

# Database configuration
DB_CONFIG = {
    'dbname': os.getenv('DB_NAME', 'law_chatbot'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', ''),
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432'),
}

# API Keys
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_ASSISTANT_API_KEY = os.getenv('OPENAI_ASSISTANT_API_KEY')

# Model configurations
EMBEDDING_MODEL_NAME = os.getenv('EMBEDDING_MODEL', 'jhgan/ko-sroberta-multitask')
LLM_MODEL_NAME = os.getenv('LLM_MODEL', 'gpt-4o-mini')
LLM_TEMPERATURE = float(os.getenv('LLM_TEMPERATURE', '0.2'))
