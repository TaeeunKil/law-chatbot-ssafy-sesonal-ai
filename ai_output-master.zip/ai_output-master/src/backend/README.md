# AI 법률 챗봇 백엔드

## 프로젝트 소개
AI 법률 챗봇 백엔드는 발생할 수 있는 다양한 법적 이슈에 대한 상담을 제공하는 AI 기반 챗봇의 백엔드 서버입니다. 이 프로젝트는 사용자 질문에 대해 법률 정보를 제공하고, 법적 문제에 대한 조언을 제공합니다.

## 기획의도 및 배경

### 개발 배경
- 세계적으로 리걸테크(Legal Tech)에 대한 투자가 이뤄지고 있지만, 한국 국내에서는 아직 법적인 문제로 인해 개발이 저조함
- 법률 상담 서비스에 대한 접근성과 편의성 향상 필요성이 뉴스에서 언급되고 있음
- 전통적인 법률 상담의 높은 비용과 시간적 제약 해소를 위한 대안 모색

### 기획 의도
1. **접근성 향상**
   - 언제 어디서나 법률 상담이 가능한 서비스 제공
   - 초기 법적 조언이 필요한 사용자들을 위한 첫걸음 지원

2. **비용 효율성**
   - 저렴한 비용으로 기본적인 법률 정보 제공
   - 복잡한 사안에 대해서만 전문가 상담을 유도하는 체계 구축

3. **정확한 정보 제공**
   - RAG(Retrieval-Augmented Generation) 기술을 활용한 신뢰할 수 있는 법률 정보 제공
   - 지속적인 업데이트를 통한 최신 법률 정보 반영

4. **사용자 경험 개선**
   - 직관적인 질의응답 시스템 구축
   - 복잡한 법률 용어를 쉽게 이해할 수 있는 설명 제공

### 기대 효과
- 법률 서비스의 접근성 향상
- 법률 상담 비용 절감
- 법률 정보 격차 해소


## 주요 기능
- 법률 상담 챗봇 API 제공
- RAG(Retrieval-Augmented Generation) 기반 정확한 법률 정보 응답
- FastAPI 기반의 안정적인 RESTful API

## 기술 스택
- Python 3.8+
- FastAPI
- PGVector
- LangChain
- OpenAI API
- Docker

## 설치 방법

### 사전 요구사항
- Python 3.8 이상
- pip (Python 패키지 관리자)
- OpenAI API 키
- (선택) Docker 및 Docker Compose

### 1. 저장소 클론
```bash
git clone https://github.com/your-username/seasonal-ai-law-chatbot-backend.git
cd seasonal-ai-law-chatbot-backend
```

### 2. 가상 환경 설정 및 활성화
```bash
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
.venv\Scripts\activate    # Windows
```

### 3. 의존성 설치
```bash
pip install -r requirements.txt
```

### 4. 환경 변수 설정
`.env` 파일을 생성하고 다음 변수들을 설정하세요:
```env
OPENAI_API_KEY=your_openai_api_key

```

## 실행 방법

### 개발 서버 실행
```bash
uvicorn app:app --reload
```

### Docker를 사용한 실행
1. Docker 이미지 빌드:
```bash
docker build -t seasonal-ai-law-chatbot .
```

2. 컨테이너 실행:
```bash
docker run -p 8000:8000 --env-file .env seasonal-ai-law-chatbot
```

## API 문서
서버가 실행된 후 다음 주소에서 API 문서를 확인할 수 있습니다:
- Swagger UI: `http://localhost:8000/docs`

## 배포
### Fly.io에 배포
해당 문서를 참고하여 배포하거나,
`https://fly.io/docs/`

또는,

```bash
flyctl launch
flyctl deploy
```

로 배포할 수 있습니다.

## 문의
문의사항이 있으시면 이슈를 생성해주세요.