import psycopg2
import psycopg2.pool
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from typing import Optional, Dict, Any, List
from contextlib import contextmanager
import logging
from config import DB_CONFIG

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Connection pool for database connections
connection_pool: Optional[psycopg2.pool.SimpleConnectionPool] = None

def init_connection_pool(min_conn: int = 1, max_conn: int = 10) -> None:
    """Initialize the connection pool.
    
    Args:
        min_conn: Minimum number of connections in the pool
        max_conn: Maximum number of connections in the pool
    """
    global connection_pool
    try:
        connection_pool = psycopg2.pool.SimpleConnectionPool(
            min_conn,
            max_conn,
            **DB_CONFIG
        )
        logger.info("Successfully created database connection pool")
    except Exception as e:
        logger.error(f"Error creating connection pool: {e}")
        raise

@contextmanager
def get_db_connection():
    """Get a database connection from the pool with context management."""
    conn = None
    try:
        if not connection_pool:
            init_connection_pool()
        conn = connection_pool.getconn()
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        yield conn
    except Exception as e:
        logger.error(f"Error getting database connection: {e}")
        raise
    finally:
        if conn:
            connection_pool.putconn(conn)

def setup_vector_extension() -> bool:
    """Verify the pgvector extension and required table structure.
    
    Returns:
        bool: True if setup is successful, False otherwise
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Check pgvector extension
                cur.execute("SELECT 1 FROM pg_extension WHERE extname = 'vector';")
                if not cur.fetchone():
                    logger.warning("pgvector extension is not enabled in the database.")
                    return False
                
                # Verify table structure
                cur.execute("""
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_name = 'question_embeddings';
                """)
                
                columns = {row[0]: row[1] for row in cur.fetchall()}
                required_columns = {
                    'id': 'integer',
                    'input': 'text',
                    'output': 'text',
                    'embedding': 'USER-DEFINED'  # For vector type
                }
                
                missing_columns = [col for col in required_columns if col not in columns]
                if missing_columns:
                    logger.error(f"Missing required columns in question_embeddings table: {missing_columns}")
                    return False
                
                logger.info("Database setup verification successful")
                return True
                
    except Exception as e:
        logger.error(f"Error during database setup verification: {e}")
        return False

def get_embedding_count() -> int:
    """Get the count of embeddings in the database."""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM question_embeddings;")
                return cur.fetchone()[0]
    except Exception as e:
        logger.error(f"Error getting embedding count: {e}")
        return -1

def search_similar_embeddings(embedding: List[float], limit: int = 5) -> List[Dict[str, Any]]:
    """Search for similar embeddings in the database.
    
    Args:
        embedding: The embedding vector to compare against
        limit: Maximum number of results to return
        
    Returns:
        List of similar embeddings with their metadata
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT id, input, output, 1 - (embedding <=> %s) as similarity
                    FROM question_embeddings
                    ORDER BY embedding <=> %s
                    LIMIT %s;
                """, (embedding, embedding, limit))
                
                return [
                    {
                        'id': row[0],
                        'input': row[1],
                        'output': row[2],
                        'similarity': float(row[3])
                    }
                    for row in cur.fetchall()
                ]
    except Exception as e:
        logger.error(f"Error searching similar embeddings: {e}")
        return []

if __name__ == "__main__":
    # Initialize connection pool
    init_connection_pool()
    
    # Verify database setup
    if setup_vector_extension():
        count = get_embedding_count()
        print(f"Database connection successful. Found {count} embeddings in the database.")
    else:
        print("Database setup verification failed. Please check the logs for details.")
