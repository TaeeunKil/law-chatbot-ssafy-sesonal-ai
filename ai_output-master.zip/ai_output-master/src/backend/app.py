from fastapi import FastAPI
from pydantic import BaseModel
from openai import AsyncOpenAI
import os
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional

load_dotenv()
openai = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatMessage(BaseModel):
    role: str
    content: str


class AssistantRequest(BaseModel):
    message: str
    thread_id: Optional[str] = None


class ChatRequest(BaseModel):
    messages: List[ChatMessage]  # Entire conversation for naive mode


# Import the RAG system
from rag import rag_system

from fastapi import Request
import logging
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from fastapi import status
from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class ChatMessage(BaseModel):
    role: str = Field(..., description="Role of the message sender (e.g., 'user' or 'assistant')")
    content: str = Field(..., description="Content of the message")

class ChatRequest(BaseModel):
    messages: List[ChatMessage] = Field(
        ...,
        description="List of messages in the conversation. The last message should be from the user.",
        example=[
            {"role": "user", "content": "의료행위로 인한 결과 발생 시 의사의 무과실 입증 책임이 요구되는 경우도 있나요?"}
        ]
    )

class SourceDocument(BaseModel):
    input: str = Field(..., description="The original question from the knowledge base")
    output: str = Field(..., description="The answer from the knowledge base")

class ChatResponse(BaseModel):
    reply: str = Field(..., description="The generated response from the RAG system")
    sources: List[SourceDocument] = Field(
        default_factory=list,
        description="List of source documents used to generate the response"
    )

@app.post(
    "/chat",
    response_model=ChatResponse,
    status_code=status.HTTP_200_OK,
    summary="법률 AI 어시스턴트와 대화하기",
    description="""
    이 엔드포인트는 법률 관련 질문을 처리하고, Retrieval-Augmented Generation (RAG) 시스템을 사용하여
    답변을 제공합니다. 시스템은 답변을 생성하기 전에 법률 정보 지식 베이스에서 관련 컨텍스트를 검색합니다.
    
    응답에는 생성된 답변과 함께 답변 생성에 사용된 출처 문서 목록이 포함됩니다.
    
    ### 요청 형식
    - **Content-Type**: `application/json`
    - **인코딩**: `UTF-8` 권장 (다른 인코딩도 지원)
    
    ### 필수 필드
    - `messages`: 대화 메시지 배열 (최소 1개 이상의 메시지 필요)
      - `role`: 메시지 발신자 (`user` 또는 `assistant`)
      - `content`: 메시지 내용
    
    ### 요청 예시
    ```json
    {
        "messages": [
            {"role": "user", "content": "의료사고 발생 시 환자 측이 입증해야 할 요건은 무엇인가요?"}
        ]
    }
    """,
    responses={
        200: {
            "description": "생성된 답변과 출처가 포함된 성공적인 응답",
            "content": {
                "application/json": {
                    "example": {
                        "reply": "의료행위로 인한 결과 발생 시 의사의 무과실 입증 책임에 대한 답변...",
                        "sources": [
                            {
                                "input": "의료행위의 결과에 대해 의사가 책임을 지는 조건은 무엇인가요?",
                                "output": "의사가 의료행위를 수행하면서 발생할 수 있는 결과에 대해 책임을 지기 위해서는..."
                            }
                        ]
                    }
                }
            }
        },
        400: {
            "description": "잘못된 요청 형식 또는 필수 필드 누락",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "Request body must be a valid JSON with 'messages' array"
                    }
                }
            }
        },
        500: {
            "description": "요청 처리 중 서버 내부 오류 발생",
            "content": {
                "application/json": {
                    "example": {
                        "detail": "An error occurred while processing your request"
                    }
                }
            }
        }
    }
)
async def chat_endpoint(request: Request):
    """
    Process a chat message and return a response using the RAG system.
    """
    try:
        # Log the raw request body for debugging
        try:
            body = await request.body()
            # Try to decode with error handling for different encodings
            try:
                body_text = body.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    body_text = body.decode('euc-kr')
                except UnicodeDecodeError:
                    body_text = body.decode('latin-1')  # Fallback to latin-1 which never fails
            
            logger.info(f"Received request body: {body_text}")
            
            # Parse the JSON from the decoded text
            try:
                data = json.loads(body_text)
            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}")
                return {"error": f"Invalid JSON format in request body: {str(e)}"}, 400
                
        except Exception as e:
            logger.error(f"Error reading request body: {str(e)}")
            return {"error": f"Error processing request: {str(e)}"}, 400
            
        # Validate the request structure
        if not isinstance(data, dict) or 'messages' not in data:
            logger.error(f"Invalid request structure: {data}")
            return {"error": "Request must contain 'messages' array"}, 400
            
        messages = data.get('messages', [])
        if not isinstance(messages, list) or not messages:
            logger.error(f"Invalid messages format: {messages}")
            return {"error": "'messages' must be a non-empty array"}, 400
            
        # Get the last message
        last_message = messages[-1]
        if not isinstance(last_message, dict) or 'role' not in last_message or 'content' not in last_message:
            logger.error(f"Invalid message format: {last_message}")
            return {"error": "Each message must have 'role' and 'content' fields"}, 400
            
        if last_message.get('role') != "user":
            return {"error": "Last message must be from a user"}, 400
            
        # Get the user's query
        query = last_message.get('content', '').strip()
        if not query:
            return {"error": "Message content cannot be empty"}, 400
        
        # Get similar documents first
        similar_docs = await rag_system.search_similar(query, k=4)
        
        # Get response from RAG system with similar documents as context
        response = await rag_system.query(query, similar_docs=similar_docs)
        
        # Format the response with sources if available
        result = {
            "reply": response,
            "sources": [
                {
                    "input": doc.get("input", ""),
                    "output": doc.get("output", "")
                }
                for doc in similar_docs
                if doc.get("input") and doc.get("output")
            ]
        }
        
        return result
        
    except Exception as e:
        # Fallback to direct OpenAI API if RAG fails
        logger.error(f"Error in chat_with_rag: {str(e)}", exc_info=True)
        try:
            response = await openai.chat.completions.create(
                model="gpt-4o-mini", 
                messages=request.messages
            )
            assistant_reply = response.choices[0].message.content
            return {
                "reply": f"[RAG System Error - Using Fallback]\n\n{assistant_reply}",
                "error": str(e)
            }
        except Exception as fallback_error:
            return {
                "reply": "죄송합니다. 시스템에 일시적인 오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
                "error": str(fallback_error)
            }


@app.post("/assistant")
async def assistant_endpoint(req: AssistantRequest):
    assistant = await openai.beta.assistants.retrieve("asst_tc4AhtsAjNJnRtpJmy1gjJOE")

    if req.thread_id:
        # We have an existing thread, append user message
        await openai.beta.threads.messages.create(
            thread_id=req.thread_id, role="user", content=req.message
        )
        thread_id = req.thread_id
    else:
        # Create a new thread with user message
        thread = await openai.beta.threads.create(
            messages=[{"role": "user", "content": req.message}]
        )
        thread_id = thread.id

    # Run and wait until complete
    await openai.beta.threads.runs.create_and_poll(
        thread_id=thread_id, assistant_id=assistant.id
    )

    # Now retrieve messages for this thread
    # messages.list returns an async iterator, so let's gather them into a list
    all_messages = [
        m async for m in openai.beta.threads.messages.list(thread_id=thread_id)
    ]
    print(all_messages)

    # The assistant's reply should be the last message with role=assistant
    assistant_reply = all_messages[0].content[0].text.value

    return {"reply": assistant_reply, "thread_id": thread_id}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
