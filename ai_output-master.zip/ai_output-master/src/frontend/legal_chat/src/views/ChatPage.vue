<template>
  <div>
    <ChatBot />
  </div>
</template>

<script>
import ChatBot from '../components/ChatBot.vue';

export default {
  components: { ChatBot }
};
</script>
