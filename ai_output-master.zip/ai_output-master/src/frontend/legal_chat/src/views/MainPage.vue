<template>
  <div class="main-container">
    <div class="content">
      <h1>SSAFY Legal Chatbot</h1>
      <p>
        법률에 대한 질문을 빠르게 해결해드립니다.<br />
        챗봇에게 질문을 입력해보세요!
      </p>
      <button @click="goToChat">시작하기</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainPage",
  methods: {
    goToChat() {
      this.$router.push("/chat");
    }
  }
};
</script>

<style scoped>
.main-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #4f8ef7, #70b5ff);
  min-height: calc(100vh - 120px);
  padding: 60px 0; 
  color: #fff;
  font-family: Arial, sans-serif;
}

.content {
  text-align: center;
  max-width: 600px;
}

h1 {
  font-size: 3rem;
  margin-bottom: 1rem;
}

p {
  font-size: 1.25rem;
  margin-bottom: 2rem;
  line-height: 1.6;
}

button {
  background-color: #fff;
  color: #007bff;
  padding: 12px 24px;
  font-size: 1.1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #e6e6e6;
}
</style>
