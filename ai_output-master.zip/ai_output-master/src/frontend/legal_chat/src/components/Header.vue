<template>
  <header class="header">
    <div class="header-content">
      <div class="title">
        <router-link to="/" class="highlight">SSAFY Legal ChatBot</router-link>
      </div>
      <button class="reset-btn" @click="$emit('reset-chat')">
        내용 초기화
      </button>
    </div>
  </header>
</template>

<script>
export default {
  name: "Header",
};
</script>

<style scoped>
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: white;
  padding: 12px 16px;
  z-index: 1000;
  border-bottom: 1px solid #ddd;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 1.1rem;
  font-weight: bold;
  color: #333;
  font-family: Arial, sans-serif;
}

.highlight {
  color: #007bff;
  text-decoration: none;
}

.reset-btn {
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 6px 12px;
  font-size: 0.85rem;
  cursor: pointer;
  margin-right : 30px;
}

.reset-btn:hover {
  background-color: #025fc3;
}
</style>
