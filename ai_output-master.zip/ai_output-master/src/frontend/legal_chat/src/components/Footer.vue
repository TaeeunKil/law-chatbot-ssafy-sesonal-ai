<template>
  <footer class="footer">
    <p>&copy; 2025 SSAFY Legal Chatbot. All rights reserved.</p>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
.footer {
  background-color: #f1f1f1;
  color: #666;
  padding: 4px 0;
  text-align: center;
  font-size: 0.9rem;
  font-family: Arial, sans-serif;
  border-top: 1px solid #ddd;
}

.footer p {
  line-height: 1.2;
  margin: 0; /* 브라우저 기본 margin 제거 */
}
</style>