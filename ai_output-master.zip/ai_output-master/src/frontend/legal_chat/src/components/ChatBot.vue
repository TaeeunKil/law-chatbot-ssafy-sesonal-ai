<template>
  <div class="chat-container">
    <Header @reset-chat="startNewChat" />

    <div class="date-label">{{ todayDate }}</div>
    <div class="chat-window chat-scroll" ref="chatContainer">
      <div v-for="(msg, index) in messages" :key="index" class="message-wrapper" :class="msg.role">
        <img
          v-if="msg.role === 'assistant'"
          src ="@/assets/legal_bot.png"
          alt="bot"
          class="avatar-img" />
        <div class="bubble" :class="{ loading: msg.loading }">
          {{ msg.content }}
        </div>
      </div>
    </div>

    <form class="input-area" @submit.prevent="handleSubmit">
      <input
        v-model="userInput"
        type="text"
        placeholder="질문을 입력하세요..."
      />
      <button type="submit">보내기</button>
    </form>
  </div>
</template>

<script>
import Header from "@/components/Header.vue"; 

export default {
  components : {
    Header,
  },
  data() {
    return {
      userInput: "",
      messages: [],
      BASE_URL: import.meta.env.VITE_API_ENDPOINT,
      db: null,
      todayDate: "",
    };
  },
  mounted() {
    this.initDB().then(this.loadExistingMessages);

    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    this.todayDate = `${year}. ${month}. ${day}`;
  },
  methods: {
    async initDB() {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open("myChatDB", 1);
        request.onupgradeneeded = (e) => {
          this.db = e.target.result;
          if (!this.db.objectStoreNames.contains("chats")) {
            this.db.createObjectStore("chats", {
              keyPath: "id",
              autoIncrement: true,
            });
          }
        };
        request.onsuccess = (e) => {
          this.db = e.target.result;
          resolve();
        };
        request.onerror = reject;
      });
    },
    saveMessage(role, content) {
      return new Promise((resolve, reject) => {
        const tx = this.db.transaction("chats", "readwrite");
        const store = tx.objectStore("chats");
        store.add({ role, content });
        tx.oncomplete = resolve;
        tx.onerror = reject;
      });
    },
    getAllMessages() {
      return new Promise((resolve, reject) => {
        const tx = this.db.transaction("chats", "readonly");
        const store = tx.objectStore("chats");
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result);
        req.onerror = reject;
      });
    },
    clearAllData() {
      return new Promise((resolve, reject) => {
        const tx = this.db.transaction(["chats"], "readwrite");
        tx.objectStore("chats").clear();
        tx.oncomplete = resolve;
        tx.onerror = reject;
      });
    },
    scrollToBottom() {
      this.$nextTick(() => {
        const container = this.$refs.chatContainer;
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
      });
    },
    typeTextSlowly(text, callback, speed = 30) {
      let i = 0;
      const interval = setInterval(() => {
        if (i < text.length) {
          callback(text.slice(0, i + 1));
          this.scrollToBottom(); // ✅ 타이핑 중마다 스크롤 내리기
          i++;
        } else {
          clearInterval(interval);
        }
      }, speed);
    },
    async sendRequestWithFallback(payload, timeout = 20000) {
      const primaryURL = import.meta.env.VITE_API_ENDPOINT;
      const fallbackURL = import.meta.env.VITE_FALLBACK_API_ENDPOINT;

      const startTime = performance.now(); // ⏱️ 요청 시작

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeout); // ⏱️ timeout 적용

      try {
        console.log("Primary backend 시도 중...");
        const res = await fetch(`${primaryURL}/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal, // ⛔️ timeout 시 중단
        });

        clearTimeout(timer);

        if (!res.ok) throw new Error("Primary backend failed");

        const endTime = performance.now(); // ✅ 응답 도착
        console.log(`✅ Primary 백엔드 응답 시간: ${(endTime - startTime).toFixed(2)}ms`);
        return await res.json();
      } catch (err) {
        console.warn("⚠️ Primary backend 실패:", err.message);

        const fallbackController = new AbortController();
        const fallbackStart = performance.now();
        const fallbackTimer = setTimeout(() => fallbackController.abort(), timeout);

        try {
          console.log("Secondary backend 시도 중...");
          const fallbackRes = await fetch(`${fallbackURL}/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
            signal: fallbackController.signal,
          });

          clearTimeout(fallbackTimer);

          if (!fallbackRes.ok) throw new Error("Fallback backend also failed");

          const fallbackEnd = performance.now();
          console.log(`✅ Fallback 백엔드 응답 시간: ${(fallbackEnd - fallbackStart).toFixed(2)}ms`);
          return await fallbackRes.json();
        } catch (fallbackError) {
          console.error("❌ 모든 백엔드 실패:", fallbackError.message);
          throw fallbackError;
        }
      }
    },
    async getAssistantResponse(userMessage) {
      const allMsgs = await this.getAllMessages();
      const messagesForAPI = [
        { role: "system", content: "You are a helpful assistant." },
        ...allMsgs.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: userMessage },
      ];

      const payload = { messages: messagesForAPI };
      const data = await this.sendRequestWithFallback(payload);
      return data.reply;
    },
    async handleSubmit() {
      const message = this.userInput.trim();
      if (!message) return;

      this.messages.push({ role: "user", content: message });
      await this.saveMessage("user", message);
      this.userInput = "";
      this.scrollToBottom();

      let index;

      try {
        // 딜레이 후 assistant bubble 추가
        await new Promise((res) => setTimeout(res, 500)); // 0.5초 delay

        // "..." 임시 메시지 추가
        const loadingMsg = { role: "assistant", content: "", loading: true };
        this.messages.push(loadingMsg);
        
        index = this.messages.length - 1;

        this.scrollToBottom();

        // 실제 응답 받아오기
        const reply = await this.getAssistantResponse(message);

        // 로딩 애니메이션 제거, 타이핑 효과로 교체
        this.messages[index] = {
          role: "assistant",
          content: "",
        };

        // 타이핑 효과 적용 (임시 메시지를 교체)
        this.typeTextSlowly(reply, (partialText) => {
          // Vue의 반응성을 보장하기 위해 전체 객체 갱신
          this.messages[index] = {
            ...this.messages[index],
            content: partialText,
          };
        });

        await this.saveMessage("assistant", reply);
        this.scrollToBottom();
      } catch (e) {
        console.error(e);

        this.messages.splice(index, 1, {
          role: "assistant",
          content: "응답을 가져오는 중 오류가 발생했습니다.",
        });

        await this.saveMessage("assistant", "응답을 가져오는 중 오류가 발생했습니다.");
        this.scrollToBottom();
      }
    },
    async loadExistingMessages() {
      const allMsgs = await this.getAllMessages();
      this.messages = allMsgs;
      this.scrollToBottom();
    },
    async startNewChat() {
      await this.clearAllData();
      this.messages = [];
    },
  },
};
</script>

<style scoped>
.chat-container {
  height: 100vh;
  max-width: 768px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  font-family: Arial, sans-serif;
  padding-top : 60px
}

.chat-window {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background-color: #ffffff;
}

.message-wrapper {
  display: flex;
  align-items: flex-start;
  margin-bottom: 16px;
}

.message-wrapper.user {
  justify-content: flex-end;
}

.message-wrapper.assistant {
  justify-content: flex-start;
}

.avatar-img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  justify-content: center;
  margin-right: 12px;
}

.bubble {
  max-width: 60%;
  padding: 12px;
  border-radius: 10px;
  line-height: 1.5;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  white-space: pre-wrap;
}

.message-wrapper.user .bubble {
  background-color: #e6e6e6;
  color: #222;
}

.message-wrapper.assistant .bubble {
  background: linear-gradient(to right, #8ca6e6, #2e61e3);
  color: white;
}

.input-area {
  display: flex;
  padding: 12px;
  border-top: 1px solid #ccc;
  background-color: #fff;

  /* ✅ 추가: 스크롤 하단에 고정되도록 */
  position: sticky;
  bottom: 0;
  z-index: 5;
}

.input-area input {
  flex: 1;
  padding: 10px;
  font-size: 15px;
  border: 1px solid #aaa;
  border-radius: 4px;
}

.input-area input:focus {
  outline: none;
  border-color: #007bff;
}

.input-area button {
  margin-left: 10px;
  padding: 10px 16px;
  font-size: 15px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.input-area button:hover {
  background-color: #0056b3;
}

.chat-scroll::-webkit-scrollbar {
  width: 6px;
}

.chat-scroll::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 3px;
}

.chat-window {
  scroll-behavior: smooth;
}

.date-label {
  text-align: center;
  font-size: 0.8rem;
  color: #555;
  margin-top: 10px;
  margin-bottom: 10px;
  font-family: 'Courier New', monospace;
  font-weight: bold;
}

.bubble.loading::after {
  content: '';
  display: inline-block;
  width: 1em;
  text-align: left;
  animation: dots 1s steps(3, end) infinite;
}

@keyframes dots {
  0% { content: ''; }
  33% { content: '.'; }
  66% { content: '..'; }
  100% { content: '...'; }
}

</style>
