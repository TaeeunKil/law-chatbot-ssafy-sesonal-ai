import asyncio
import logging
from typing import List, Dict, Any

from rag import RAGSystem
from db_utils import init_connection_pool, setup_vector_extension, get_embedding_count

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_rag_system():
    """Test the RAG system with various queries."""
    # Initialize the RAG system
    rag = RAGSystem()
    
    # Test cases
    test_queries = [
        "골프 경기 중 선수의 공이 빗나가 다른 사람에게 상해를 입혔을 때 선수에게 요구되는 주의의무는 무엇인가요?",
        "피보험자가 입원하지 않았음에도 불구하고 입원확인서를 발급받아 보험금을 청구할 경우 어떤 법적 책임이 따르나요?",
        "의료행위로 인한 결과 발생 시 의사의 무과실 입증 책임이 요구되는 경우도 있나요?"
    ]
    
    for query in test_queries:
        print(f"\n{'='*50}")
        print(f"Testing query: {query}")
        
        # Test embedding generation
        print("\n1. Testing embedding generation...")
        embedding = await rag.get_embedding(query)
        if embedding and isinstance(embedding, list) and len(embedding) > 0:
            print(f"✅ Successfully generated embedding (length: {len(embedding)})")
        else:
            print("❌ Failed to generate embedding")
            continue
        
        # Test similarity search
        print("\n2. Testing similarity search...")
        similar_docs = await rag.search_similar(query, k=2)
        if similar_docs and isinstance(similar_docs, list):
            print(f"✅ Found {len(similar_docs)} similar documents")
            for i, doc in enumerate(similar_docs, 1):
                print(f"\nDocument {i} (Similarity: {doc.get('score', 0):.2f}):")
                print(f"Input: {doc.get('input', 'N/A')[:200]}...")
                print(f"Output: {doc.get('output', 'N/A')[:200]}...")
        else:
            print("❌ No similar documents found")
            continue
        
        # Test RAG query
        print("\n3. Testing RAG response...")
        try:
            response = await rag.query(query)
            print(f"✅ RAG Response:")
            print(response)
        except Exception as e:
            print(f"❌ Error in RAG query: {e}")
    
    print("\n" + "="*50)
    print("✅ All tests completed")

async def main():
    # Initialize database connection pool
    init_connection_pool()
    
    # Verify database setup
    if not setup_vector_extension():
        print("❌ Database setup verification failed. Please check the logs.")
        return
    
    # Get embedding count
    count = get_embedding_count()
    print(f"\n📊 Found {count} embeddings in the database")
    
    # Run RAG tests
    await test_rag_system()

if __name__ == "__main__":
    asyncio.run(main())
