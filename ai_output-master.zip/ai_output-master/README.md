<p align="center">

  <h1> SSAFY Legal Chatbot </h1>

</p>

![image-2](/uploads/9383bad461862fe78cb90f17c9767725/image-2.png)

<br>

>SSAFY Legal Chatbot은  임대차 분쟁, 근로계약, 소비자 권리 등 일상에서 마주치는 생활법률 이슈에 대해 정보를 찾기 어렵거나 변호사 상담이 부담되는 사용자를 위해, 정확하고 신뢰할 수 있는 법률 정보를 자동으로 제공하는 챗봇 서비스입니다. 

<br>

🖥 **[SSAFY Legal Chatbot 체험하기](https://main.d1wu48zue8p0tl.amplifyapp.com/)**


## ⚙️ Use Case

>1. 웹 서버 접속
>2. 메시지 프롬프트 창에 법적 질문 입력
>3. AI 모델이 답변을 메시지 형태로 제공

<br>
